# Wild-Lake site project

Source snapshot: e13f470

The wild-lake-site folder contains the complete static website, including page HTML, stylesheets, JavaScript, fonts, portraits, social preview artwork, structured JSON, llms.txt, and published Reel downloads.

## Run locally

From the extracted project folder:

```sh
cd wild-lake-site
python3 -m http.server 8000
```

Open http://localhost:8000 in your browser. Python 3 is the only requirement for this local server. There is no dependency installation or build step. Use an HTTP server rather than opening the HTML files directly because page assets use root-relative paths.

## Pages

- /: Homepage and animated stacked monolith
- /roster/: Artist and athlete roster
- /about-founder/: Founder biography and portrait
- /contact/: Optional intake prompts that prepare an email draft
- /schema/: Public structured descriptions

## Deployment

The contents of wild-lake-site are the static document root. The production site is served through Cloudflare Workers static assets at https://wild-lake.org/. Configure your own Cloudflare project and deploy this directory as its assets. No account credentials, tokens, Git metadata, or cloud-environment files are included. Live Cloudflare account settings are not part of this source archive.
